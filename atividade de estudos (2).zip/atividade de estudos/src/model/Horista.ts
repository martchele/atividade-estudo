import { Empregado } from "./Empregado";

export class Horista extends Empregado{
    private valorHora: number;
    private horaTrabalhadas:number;

    public constructor (_nome:string, _cpf:string, _valorHora:number, _horaTrabalhadas:number){
     super(_nome, _cpf) 
     this.valorHora = _valorHora;
     this.horaTrabalhadas = _horaTrabalhadas;
    }

    public setValorHora(_valorHora:number):void{
        this.valorHora = _valorHora;
    }
    public getValorHora(): number{
        return this.valorHora;
    }
    public setHoraTrabalhadas (_horaTrabalhadas:number): void{
        this.horaTrabalhadas = _horaTrabalhadas;
    }
    public getHoraTrabalhadas(): number{
        return this.horaTrabalhadas;
    }
    public vencimento(): number {
        return this.valorHora + (this.valorHora*this.horaTrabalhadas);
    }

}